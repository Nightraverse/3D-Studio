#version 450

out vec4  fColor;

void
main()
{
    fColor = vec4( 1.0, 0.0, 1.0, 1.0 );
}
