#include "fileReader.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <string>

int loadObj(const std::string& filename, Model& model){
// -- Stage 2: Parse File --------------------------
    std::ifstream readFile(filename);
    if (!readFile) {
        std::cerr << "File not found." << std::endl; 
        return 1;
    }
    
    std::string currentLine; 
    
    while (getline(readFile, currentLine)) {
        std::istringstream ss(currentLine);
        std::string tag;
        ss >> tag; 

        if (tag == "v") {
            float x, y, z;
            ss >> x >> y >> z;
            model.vertices.push_back(x);
            model.vertices.push_back(y);
            model.vertices.push_back(z);
        }
        else if (tag == "f") {
            std::vector<faceVertex> face;
            std::string token;
            
            while (ss >> token) {
                std::istringstream tokenStream(token);
                std::string indexString;
                faceVertex fv;
                
                if (std::getline(tokenStream, indexString, '/')) {
                    fv.v = std::stoi(indexString) - 1;
                }
                if (std::getline(tokenStream, indexString, '/')) {
                    if (!indexString.empty()) fv.vt = std::stoi(indexString) - 1;
                }
                if (std::getline(tokenStream, indexString, '/')) {
                    if (!indexString.empty()) fv.vn = std::stoi(indexString) - 1;
                }
                face.push_back(fv);
            }

            model.faceGroups.push_back(face);
        }
    }
    
    readFile.close(); 
    scaleToUnitCube(model.vertices);
    model.triangles = triangulate(model.faceGroups);
    return 0;
}

// -- Stage 3: Triangulate Faces ---------------------------
std::vector<faceVertex> triangulate(const std::vector<std::vector<faceVertex>>& faceGroups) {
    std::vector<faceVertex> triangles;
    for (const auto& face : faceGroups) {
        for (size_t i = 2; i < face.size(); i++) {
            triangles.push_back(face[0]);
            triangles.push_back(face[i - 1]);
            triangles.push_back(face[i]);
        }
    }
    return triangles;
}

// -- Stage 4: Output Parsed File --------------------------
int test(const Model& model) {
    std::cout << "Vertices: " << model.vertices.size() / 3 << "\n";
    std::cout << "Faces: " << model.faceGroups.size() << "\n";
    std::cout << "Triangles: " << model.triangles.size() / 3 << "\n";
    return 0;
}

// -- Stage 5: Scale to Unit Cube --------------------------
void scaleToUnitCube(std::vector<float>& vertices) {
    if (vertices.empty()) return;
    float minX, minY, minZ, maxX, maxY, maxZ;

    minX = maxX = vertices[0];
    minY = maxY = vertices[1];
    minZ = maxZ = vertices[2];

    for (size_t i = 3; i < vertices.size(); i += 3) {
        if (vertices[i] < minX) minX = vertices[i];
        if (vertices[i] > maxX) maxX = vertices[i];
        if (vertices[i + 1] < minY) minY = vertices[i + 1];
        if (vertices[i + 1] > maxY) maxY = vertices[i + 1];
        if (vertices[i + 2] < minZ) minZ = vertices[i + 2];
        if (vertices[i + 2] > maxZ) maxZ = vertices[i + 2];
    }

    float extentX = maxX - minX;
    float extentY = maxY - minY;
    float extentZ = maxZ - minZ;

    float maxScale = std::max({ extentX, extentY, extentZ });
    if (maxScale == 0) return;

    float cx = (minX + maxX) / 2.0f;
    float cy = (minY + maxY) / 2.0f;
    float cz = (minZ + maxZ) / 2.0f;

    for (size_t i = 0; i < vertices.size(); i += 3) {
        vertices[i] = (vertices[i] - cx) / maxScale;
        vertices[i + 1] = (vertices[i + 1] - cy) / maxScale;
        vertices[i + 2] = (vertices[i + 2] - cz) / maxScale;
    }
}
