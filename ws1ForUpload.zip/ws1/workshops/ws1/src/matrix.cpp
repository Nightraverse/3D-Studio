#include "matrix.h"


namespace {

    float& elem(Mat4x4& m, int row, int col){
        return m[(col - 1) * 4 + (row - 1)];
    }

    float elem(const Mat4x4& m, int row, int col){
        return m[(col - 1) * 4 + (row - 1)];
    }
    
} // namespace


void setIdentity(Mat4x4& m){
    for(int row = 1; row <= 4; ++row){
        for(int col = 1; col <= 4; ++col){
            elem(m, row, col) = (row == col) ? 1.0f : 0.f;
        }
    }
}


// set M = transformation matrix * M
void applyTransform(const Mat4x4& transform, Mat4x4& m) {
    Mat4x4 result{};
    for (int row = 1; row <= 4; ++row){
        for (int col = 1; col <= 4; ++col){
            for (int k = 1; k <= 4; ++k){
                elem(result, row, col) += elem(transform, row, k) * elem(m, k, col);
            }
        }
    }

    for (int i = 0; i < 16; ++i) { m[i] = result[i];}
}

void makeTranslation(Mat4x4& t, float x, float y, float z){

    setIdentity(t);
    elem(t, 1, 4) = x;
    elem(t, 2, 4) = y;
    elem(t, 3, 4) = z;
}

void makeScale(Mat4x4& s, float x, float y, float z){
    setIdentity(s);
    elem(s, 1, 1) = x;
    elem(s, 2, 2) = y;
    elem(s, 3, 3) = z;
}

void makeRotation(Mat4x4& r, int axis, float radians) {

    setIdentity(r);
    
    const float c = std::cos(radians);
    const float s = std::sin(radians);

    // X rotates Y and Z
    if (axis == 0){            
        elem(r, 2, 2) = c; elem(r, 2, 3) = -s;
        elem(r, 3, 2) = s; elem(r, 3, 3) = c;
    }

    // Y rotates X and Z
    else if (axis == 1){     
        elem(r, 1, 1) = c; elem(r, 1, 3) = s;
        elem(r, 3, 1) = -s; elem(r, 3, 3) = c;
    } 

    // Z rotates X and Y
    else{                   
        elem(r, 1, 1) = c; elem(r, 1, 2) = -s;
        elem(r, 2, 1) = s; elem(r, 2, 2) = c;
    }
} 
