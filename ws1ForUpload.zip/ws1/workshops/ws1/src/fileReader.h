#ifndef MODEL_H
#define MODEL_H

#include <vector>
#include <string>

// holds a the vertexes for a face (includes point, texture and normal, holds -1 where something isnt set)
struct faceVertex {
    // -1 is an initial value to indicate that the vertex has not been set yet 
    int v = -1;
    int vt = -1;
    int vn = -1;
};

// Holds all the data for a 3D model, including vertices, face groups, and triangles
struct Model {
    std::vector<float> vertices;
    std::vector<std::vector<faceVertex>> faceGroups;
    std::vector<faceVertex> triangles;
};

// function declarations (Prototypes)
int loadObj(const std::string& filename, Model& model);int test(const Model& model);
void scaleToUnitCube(std::vector<float>& vertices);
std::vector<faceVertex> triangulate(const std::vector<std::vector<faceVertex>>& faceGroups);

#endif 
