#pragma once

#include "3dstudio.h"  // Mat4x4
#include "fileReader.h"
#include "geometryrender.h"
#include <stdexcept>
#include <cmath>

void setIdentity(Mat4x4& m);
void applyTransform(const Mat4x4& transform, Mat4x4& m);
void makeTranslation(Mat4x4& t, float x, float y, float z);
void makeScale(Mat4x4& s, float x, float y, float z);
void makeRotation(Mat4x4& r, int axis, float radians);